/**
 * Students Module - Handles student management functionality
 */

let currentEditingStudentId = null;

const Students = {
    
    init: function() {
        this.loadStudents();
        this.setupEventListeners();
    },
    
    setupEventListeners: function() {
        // Add Student Button
        document.getElementById('addStudentBtn')?.addEventListener('click', () => {
            currentEditingStudentId = null;
            document.getElementById('studentModalTitle').textContent = 'Add Student';
            document.getElementById('studentForm').reset();
            new bootstrap.Modal(document.getElementById('studentModal')).show();
        });
        
        // Submit Student Form
        document.getElementById('submitStudentBtn')?.addEventListener('click', () => {
            this.submitStudentForm();
        });
        
        // Search Students
        document.getElementById('studentSearch')?.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            if (query.length > 0) {
                this.searchStudents(query);
            } else {
                this.loadStudents();
            }
        });
        
        // Department Filter
        document.getElementById('departmentFilter')?.addEventListener('change', (e) => {
            const dept = e.target.value;
            if (dept) {
                this.filterByDepartment(dept);
            } else {
                this.loadStudents();
            }
        });
        
        // Action buttons in dashboard
        document.querySelectorAll('[data-action="addStudent"]').forEach(btn => {
            btn.addEventListener('click', () => {
                currentEditingStudentId = null;
                document.getElementById('studentModalTitle').textContent = 'Add Student';
                document.getElementById('studentForm').reset();
                new bootstrap.Modal(document.getElementById('studentModal')).show();
            });
        });
    },
    
    loadStudents: async function() {
        const result = await API.getStudents();
        
        if (result.success) {
            this.displayStudents(result.data);
            this.loadDepartments();
        } else {
            alert('Error loading students: ' + result.error);
        }
    },
    
    displayStudents: function(students) {
        const tbody = document.getElementById('studentTableBody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        if (students.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No students found</td></tr>';
            return;
        }
        
        students.forEach(student => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${student.id}</td>
                <td>${student.name}</td>
                <td>${student.roll_number}</td>
                <td>${student.department}</td>
                <td>${student.year}</td>
                <td>
                    <div class="action-buttons-group">
                        <button class="btn btn-sm btn-edit" onclick="Students.editStudent(${student.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-delete" onclick="Students.deleteStudent(${student.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    },
    
    submitStudentForm: async function() {
        const name = document.getElementById('studentName').value.trim();
        const roll = document.getElementById('studentRoll').value.trim();
        const dept = document.getElementById('studentDept').value.trim();
        const year = document.getElementById('studentYear').value;
        
        if (!name || !roll || !dept || !year) {
            alert('All fields are required');
            return;
        }
        
        const data = {
            name: name,
            roll_number: roll,
            department: dept,
            year: parseInt(year)
        };
        
        let result;
        
        if (currentEditingStudentId) {
            result = await API.updateStudent(currentEditingStudentId, data);
        } else {
            result = await API.addStudent(data);
        }
        
        if (result.success) {
            bootstrap.Modal.getInstance(document.getElementById('studentModal')).hide();
            this.loadStudents();
            alert(currentEditingStudentId ? 'Student updated successfully' : 'Student added successfully');
        } else {
            alert('Error: ' + result.error);
        }
    },
    
    editStudent: async function(id) {
        const result = await API.getStudents();
        const student = result.data.find(s => s.id === id);
        
        if (!student) {
            alert('Student not found');
            return;
        }
        
        currentEditingStudentId = id;
        document.getElementById('studentModalTitle').textContent = 'Edit Student';
        document.getElementById('studentName').value = student.name;
        document.getElementById('studentRoll').value = student.roll_number;
        document.getElementById('studentDept').value = student.department;
        document.getElementById('studentYear').value = student.year;
        
        new bootstrap.Modal(document.getElementById('studentModal')).show();
    },
    
    deleteStudent: async function(id) {
        if (!confirm('Are you sure you want to delete this student?')) {
            return;
        }
        
        const result = await API.deleteStudent(id);
        
        if (result.success) {
            this.loadStudents();
            alert('Student deleted successfully');
        } else {
            alert('Error deleting student: ' + result.error);
        }
    },
    
    searchStudents: async function(query) {
        const result = await API.searchStudents(query);
        
        if (result.success) {
            this.displayStudents(result.data);
        }
    },
    
    filterByDepartment: async function(dept) {
        const result = await API.getStudentsByDepartment(dept);
        
        if (result.success) {
            this.displayStudents(result.data);
        }
    },
    
    loadDepartments: async function() {
        const result = await API.getDepartments();
        
        if (result.success && result.departments) {
            const select = document.getElementById('departmentFilter');
            if (select) {
                const currentValue = select.value;
                select.innerHTML = '<option value="">All Departments</option>';
                result.departments.forEach(dept => {
                    const option = document.createElement('option');
                    option.value = dept;
                    option.textContent = dept;
                    select.appendChild(option);
                });
                select.value = currentValue;
            }
        }
    }
};

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('studentTableBody')) {
        Students.init();
    }
});
