/**
 * API Module - Handles all REST API calls
 * This module provides functions to communicate with the backend REST API
 */

const API = {
    
    // ==================== STUDENTS ====================
    
    getStudents: async function() {
        try {
            const response = await fetch('/api/students');
            return await response.json();
        } catch (error) {
            console.error('Error fetching students:', error);
            return { success: false, error: error.message };
        }
    },
    
    addStudent: async function(data) {
        try {
            const response = await fetch('/api/students', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            return await response.json();
        } catch (error) {
            console.error('Error adding student:', error);
            return { success: false, error: error.message };
        }
    },
    
    updateStudent: async function(id, data) {
        try {
            const response = await fetch(`/api/students/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            return await response.json();
        } catch (error) {
            console.error('Error updating student:', error);
            return { success: false, error: error.message };
        }
    },
    
    deleteStudent: async function(id) {
        try {
            const response = await fetch(`/api/students/${id}`, {
                method: 'DELETE'
            });
            return await response.json();
        } catch (error) {
            console.error('Error deleting student:', error);
            return { success: false, error: error.message };
        }
    },
    
    searchStudents: async function(query) {
        try {
            const response = await fetch(`/api/students/search?q=${encodeURIComponent(query)}`);
            return await response.json();
        } catch (error) {
            console.error('Error searching students:', error);
            return { success: false, error: error.message };
        }
    },
    
    getStudentsByDepartment: async function(department) {
        try {
            const response = await fetch(`/api/students/department/${encodeURIComponent(department)}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching students by department:', error);
            return { success: false, error: error.message };
        }
    },
    
    getTotalStudents: async function() {
        try {
            const response = await fetch('/api/students/stats/total');
            return await response.json();
        } catch (error) {
            console.error('Error fetching total students:', error);
            return { success: false, error: error.message };
        }
    },
    
    getDepartments: async function() {
        try {
            const response = await fetch('/api/departments');
            return await response.json();
        } catch (error) {
            console.error('Error fetching departments:', error);
            return { success: false, error: error.message };
        }
    },
    
    // ==================== EXAMS ====================
    
    getExams: async function() {
        try {
            const response = await fetch('/api/exams');
            return await response.json();
        } catch (error) {
            console.error('Error fetching exams:', error);
            return { success: false, error: error.message };
        }
    },
    
    addExam: async function(data) {
        try {
            const response = await fetch('/api/exams', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            return await response.json();
        } catch (error) {
            console.error('Error adding exam:', error);
            return { success: false, error: error.message };
        }
    },
    
    updateExam: async function(id, data) {
        try {
            const response = await fetch(`/api/exams/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            return await response.json();
        } catch (error) {
            console.error('Error updating exam:', error);
            return { success: false, error: error.message };
        }
    },
    
    deleteExam: async function(id) {
        try {
            const response = await fetch(`/api/exams/${id}`, {
                method: 'DELETE'
            });
            return await response.json();
        } catch (error) {
            console.error('Error deleting exam:', error);
            return { success: false, error: error.message };
        }
    },
    
    checkExamConflict: async function(date, time, duration) {
        try {
            const response = await fetch('/api/exams/check-conflict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ date, time, duration })
            });
            return await response.json();
        } catch (error) {
            console.error('Error checking exam conflict:', error);
            return { success: false, error: error.message };
        }
    },
    
    getTotalExams: async function() {
        try {
            const response = await fetch('/api/exams/stats/total');
            return await response.json();
        } catch (error) {
            console.error('Error fetching total exams:', error);
            return { success: false, error: error.message };
        }
    },
    
    // ==================== HALLS ====================
    
    getHalls: async function() {
        try {
            const response = await fetch('/api/halls');
            return await response.json();
        } catch (error) {
            console.error('Error fetching halls:', error);
            return { success: false, error: error.message };
        }
    },
    
    addHall: async function(data) {
        try {
            const response = await fetch('/api/halls', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            return await response.json();
        } catch (error) {
            console.error('Error adding hall:', error);
            return { success: false, error: error.message };
        }
    },
    
    updateHall: async function(id, data) {
        try {
            const response = await fetch(`/api/halls/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            return await response.json();
        } catch (error) {
            console.error('Error updating hall:', error);
            return { success: false, error: error.message };
        }
    },
    
    deleteHall: async function(id) {
        try {
            const response = await fetch(`/api/halls/${id}`, {
                method: 'DELETE'
            });
            return await response.json();
        } catch (error) {
            console.error('Error deleting hall:', error);
            return { success: false, error: error.message };
        }
    },
    
    getTotalHalls: async function() {
        try {
            const response = await fetch('/api/halls/stats/total');
            return await response.json();
        } catch (error) {
            console.error('Error fetching total halls:', error);
            return { success: false, error: error.message };
        }
    },
    
    getTotalCapacity: async function() {
        try {
            const response = await fetch('/api/halls/stats/capacity');
            return await response.json();
        } catch (error) {
            console.error('Error fetching total capacity:', error);
            return { success: false, error: error.message };
        }
    },
    
    // ==================== SEATING ====================
    
    generateSeating: async function(examId) {
        try {
            const response = await fetch(`/api/seating/generate/${examId}`, {
                method: 'POST'
            });
            return await response.json();
        } catch (error) {
            console.error('Error generating seating:', error);
            return { success: false, error: error.message };
        }
    },
    
    getSeatingLayout: async function(examId) {
        try {
            const response = await fetch(`/api/seating/layout/${examId}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching seating layout:', error);
            return { success: false, error: error.message };
        }
    },
    
    searchStudentSeat: async function(rollNumber, examId) {
        try {
            const response = await fetch(`/api/seating/search?roll_number=${encodeURIComponent(rollNumber)}&exam_id=${examId}`);
            return await response.json();
        } catch (error) {
            console.error('Error searching student seat:', error);
            return { success: false, error: error.message };
        }
    },
    
    getHallLayout: async function(hallId, examId) {
        try {
            const response = await fetch(`/api/seating/hall/${hallId}/exam/${examId}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching hall layout:', error);
            return { success: false, error: error.message };
        }
    },
    
    finalizeSeating: async function(examId) {
        try {
            const response = await fetch(`/api/seating/finalize/${examId}`, {
                method: 'POST'
            });
            return await response.json();
        } catch (error) {
            console.error('Error finalizing seating:', error);
            return { success: false, error: error.message };
        }
    },
    
    getAttendanceSheet: async function(examId, hallId = null) {
        try {
            let url = `/api/seating/attendance/${examId}`;
            if (hallId) {
                url += `?hall_id=${hallId}`;
            }
            const response = await fetch(url);
            return await response.json();
        } catch (error) {
            console.error('Error fetching attendance sheet:', error);
            return { success: false, error: error.message };
        }
    },
    
    getSeatingStatistics: async function(examId) {
        try {
            const response = await fetch(`/api/seating/statistics/${examId}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching seating statistics:', error);
            return { success: false, error: error.message };
        }
    }
};
