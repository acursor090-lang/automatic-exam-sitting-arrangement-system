/**
 * Seating Module - Handles seating arrangement core functionality
 */

let currentEditingHallId = null;

const Seating = {
    
    init: function() {
        this.loadHalls();
        this.setupEventListeners();
    },
    
    setupEventListeners: function() {
        // Add Hall Button
        document.getElementById('addHallBtn')?.addEventListener('click', () => {
            currentEditingHallId = null;
            document.getElementById('hallModalTitle').textContent = 'Add Hall';
            document.getElementById('hallForm').reset();
            new bootstrap.Modal(document.getElementById('hallModal')).show();
        });
        
        // Submit Hall Form
        document.getElementById('submitHallBtn')?.addEventListener('click', () => {
            this.submitHallForm();
        });
        
        // Action buttons in dashboard
        document.querySelectorAll('[data-action="addHall"]').forEach(btn => {
            btn.addEventListener('click', () => {
                currentEditingHallId = null;
                document.getElementById('hallModalTitle').textContent = 'Add Hall';
                document.getElementById('hallForm').reset();
                new bootstrap.Modal(document.getElementById('hallModal')).show();
            });
        });
        
        // Seating page controls
        document.getElementById('generateSeatingBtn')?.addEventListener('click', () => {
            this.generateSeating();
        });
        
        document.getElementById('viewSeatingBtn')?.addEventListener('click', () => {
            this.viewSeatingLayout();
        });
        
        document.getElementById('searchBtn')?.addEventListener('click', () => {
            this.searchStudent();
        });
        
        // Enter key in search
        document.getElementById('rollNumberInput')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.searchStudent();
            }
        });
        
        // Download buttons
        document.getElementById('downloadPdfBtn')?.addEventListener('click', () => {
            alert('PDF export functionality coming soon');
        });
        
        document.getElementById('downloadExcelBtn')?.addEventListener('click', () => {
            alert('Excel export functionality coming soon');
        });
    },
    
    loadHalls: async function() {
        const result = await API.getHalls();
        
        if (result.success) {
            this.displayHalls(result.data);
        } else {
            alert('Error loading halls: ' + result.error);
        }
    },
    
    displayHalls: function(halls) {
        const tbody = document.getElementById('hallTableBody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        if (halls.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No halls found</td></tr>';
            return;
        }
        
        halls.forEach(hall => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${hall.id}</td>
                <td>${hall.hall_name}</td>
                <td>${hall.capacity}</td>
                <td>${hall.floor}</td>
                <td>
                    <div class="action-buttons-group">
                        <button class="btn btn-sm btn-edit" onclick="Seating.editHall(${hall.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-delete" onclick="Seating.deleteHall(${hall.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    },
    
    submitHallForm: async function() {
        const name = document.getElementById('hallName').value.trim();
        const capacity = document.getElementById('hallCapacity').value;
        const floor = document.getElementById('hallFloor').value;
        
        if (!name || !capacity || !floor) {
            alert('All fields are required');
            return;
        }
        
        const data = {
            hall_name: name,
            capacity: parseInt(capacity),
            floor: parseInt(floor)
        };
        
        let result;
        
        if (currentEditingHallId) {
            result = await API.updateHall(currentEditingHallId, data);
        } else {
            result = await API.addHall(data);
        }
        
        if (result.success) {
            bootstrap.Modal.getInstance(document.getElementById('hallModal')).hide();
            this.loadHalls();
            alert(currentEditingHallId ? 'Hall updated successfully' : 'Hall added successfully');
        } else {
            alert('Error: ' + result.error);
        }
    },
    
    editHall: async function(id) {
        const result = await API.getHalls();
        const hall = result.data.find(h => h.id === id);
        
        if (!hall) {
            alert('Hall not found');
            return;
        }
        
        currentEditingHallId = id;
        document.getElementById('hallModalTitle').textContent = 'Edit Hall';
        document.getElementById('hallName').value = hall.hall_name;
        document.getElementById('hallCapacity').value = hall.capacity;
        document.getElementById('hallFloor').value = hall.floor;
        
        new bootstrap.Modal(document.getElementById('hallModal')).show();
    },
    
    deleteHall: async function(id) {
        if (!confirm('Are you sure you want to delete this hall?')) {
            return;
        }
        
        const result = await API.deleteHall(id);
        
        if (result.success) {
            this.loadHalls();
            alert('Hall deleted successfully');
        } else {
            alert('Error deleting hall: ' + result.error);
        }
    },
    
    generateSeating: async function() {
        const examSelect = document.getElementById('examSelect');
        const examId = examSelect?.value;
        
        if (!examId) {
            alert('Please select an exam');
            return;
        }
        
        if (!confirm('Generate seating arrangement for this exam? This will overwrite any existing arrangement.')) {
            return;
        }
        
        // Show loading message
        const layoutDiv = document.getElementById('seatingLayout');
        if (layoutDiv) {
            layoutDiv.innerHTML = '<div class="alert alert-info"><i class="fas fa-spinner fa-spin"></i> Generating seating arrangement...</div>';
        }
        
        const result = await API.generateSeating(parseInt(examId));
        
        if (result.success) {
            alert('Seating arrangement generated successfully!\n' + result.message);
            this.viewSeatingLayout();
        } else {
            alert('Error: ' + result.error);
            if (layoutDiv) {
                layoutDiv.innerHTML = '';
            }
        }
    },
    
    viewSeatingLayout: async function() {
        const examSelect = document.getElementById('examSelect');
        const examId = examSelect?.value;
        
        if (!examId) {
            alert('Please select an exam');
            return;
        }
        
        const result = await API.getSeatingLayout(parseInt(examId));
        
        if (result.success) {
            this.displaySeatingLayout(result.data);
        } else {
            alert('Error: ' + result.error);
        }
    },
    
    displaySeatingLayout: function(layout) {
        const layoutDiv = document.getElementById('seatingLayout');
        if (!layoutDiv) return;
        
        layoutDiv.innerHTML = '';
        
        if (!layout || Object.keys(layout).length === 0) {
            layoutDiv.innerHTML = '<div class="alert alert-warning">No seating arrangement generated yet</div>';
            return;
        }
        
        for (const [hallName, seats] of Object.entries(layout)) {
            const hallDiv = document.createElement('div');
            hallDiv.className = 'hall-layout';
            
            hallDiv.innerHTML = `<h4>${hallName}</h4>`;
            
            const seatsGrid = document.createElement('div');
            seatsGrid.className = 'seats-grid';
            
            seats.forEach(seat => {
                const seatDiv = document.createElement('div');
                seatDiv.className = 'seat ' + (seat.student_id ? 'occupied' : 'available');
                
                if (seat.student_id) {
                    seatDiv.innerHTML = `
                        <span title="${seat.roll_number || 'Unallocated'}">
                            ${seat.seat_number}
                        </span>
                    `;
                } else {
                    seatDiv.innerHTML = `<span>${seat.seat_number}</span>`;
                }
                
                seatsGrid.appendChild(seatDiv);
            });
            
            hallDiv.appendChild(seatsGrid);
            layoutDiv.appendChild(hallDiv);
        }
    },
    
    searchStudent: async function() {
        const rollNumber = document.getElementById('rollNumberInput')?.value.trim();
        const examSelect = document.getElementById('examSelect');
        const examId = examSelect?.value;
        
        if (!rollNumber) {
            alert('Please enter a roll number');
            return;
        }
        
        if (!examId) {
            alert('Please select an exam');
            return;
        }
        
        const result = await API.searchStudentSeat(rollNumber, parseInt(examId));
        const searchResult = document.getElementById('searchResult');
        
        if (!searchResult) return;
        
        if (result.success) {
            searchResult.innerHTML = `
                <div class="alert alert-success">
                    <h6>Student Found</h6>
                    <p><strong>Roll Number:</strong> ${result.data.roll_number}</p>
                    <p><strong>Hall:</strong> ${result.data.hall_name}</p>
                    <p><strong>Seat Number:</strong> <span class="badge bg-primary">${result.data.seat_number}</span></p>
                </div>
            `;
            searchResult.classList.add('show');
        } else {
            searchResult.innerHTML = `
                <div class="alert alert-warning">
                    ${result.error}
                </div>
            `;
            searchResult.classList.add('show');
        }
    }
};

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('hallTableBody')) {
        Seating.init();
    }
});
