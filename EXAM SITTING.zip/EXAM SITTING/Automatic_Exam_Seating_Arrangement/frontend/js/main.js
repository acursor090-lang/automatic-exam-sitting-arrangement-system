/**
 * Main Module - Handles page navigation and dashboard initialization
 */

const Main = {
    
    init: function() {
        this.setupNavigation();
        this.loadDashboardStats();
        this.setupSidebarToggle();
    },
    
    setupNavigation: function() {
        // Menu items
        document.querySelectorAll('.sidebar-menu a[data-page]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = link.dataset.page;
                this.navigateToPage(page);
                
                // Update active menu item
                document.querySelectorAll('.sidebar-menu li').forEach(li => {
                    li.classList.remove('active');
                });
                link.parentElement.classList.add('active');
            });
        });
    },
    
    navigateToPage: function(page) {
        // Hide all pages
        document.querySelectorAll('.page-content').forEach(content => {
            content.style.display = 'none';
        });
        
        // Show selected page
        const pageElement = document.getElementById(page + 'Page');
        if (pageElement) {
            pageElement.style.display = 'block';
            
            // Update page title
            const titles = {
                'dashboard': 'Dashboard',
                'students': 'Student Management',
                'exams': 'Exam Management',
                'halls': 'Hall Management',
                'seating': 'Seating Arrangement',
                'reports': 'Reports'
            };
            
            document.getElementById('pageTitle').textContent = titles[page] || 'Page';
            
            // Reload data if necessary
            if (page === 'students') {
                Students?.loadStudents();
            } else if (page === 'exams') {
                Exams?.loadExams();
            } else if (page === 'halls') {
                Seating?.loadHalls();
            } else if (page === 'seating') {
                Seating?.loadExamsToSelect?.();
            } else if (page === 'dashboard') {
                this.loadDashboardStats();
            }
        }
        
        // Close mobile sidebar if open
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.remove('active');
        }
    },
    
    loadDashboardStats: async function() {
        try {
            const [
                studentResult,
                examResult,
                hallResult,
                capacityResult
            ] = await Promise.all([
                API.getTotalStudents(),
                API.getTotalExams(),
                API.getTotalHalls(),
                API.getTotalCapacity()
            ]);
            
            // Update stats
            if (studentResult.success && studentResult.count !== undefined) {
                const elem = document.getElementById('totalStudents');
                if (elem) elem.textContent = studentResult.count;
            }
            
            if (examResult.success && examResult.count !== undefined) {
                const elem = document.getElementById('totalExams');
                if (elem) elem.textContent = examResult.count;
            }
            
            if (hallResult.success && hallResult.count !== undefined) {
                const elem = document.getElementById('totalHalls');
                if (elem) elem.textContent = hallResult.count;
            }
            
            if (capacityResult.success && capacityResult.total_capacity !== undefined) {
                const elem = document.getElementById('totalCapacity');
                if (elem) elem.textContent = capacityResult.total_capacity;
            }
        } catch (error) {
            console.error('Error loading dashboard stats:', error);
        }
    },
    
    setupSidebarToggle: function() {
        const toggleBtn = document.getElementById('sidebarToggle');
        const sidebar = document.querySelector('.sidebar');
        
        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', () => {
                sidebar.classList.toggle('active');
            });
            
            // Close sidebar when clicking outside
            document.addEventListener('click', (e) => {
                if (!e.target.closest('.sidebar') && 
                    !e.target.closest('.sidebar-toggle') &&
                    sidebar.classList.contains('active')) {
                    sidebar.classList.remove('active');
                }
            });
        }
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    Main.init();
    Students?.init?.();
    Exams?.init?.();
    Seating?.init?.();
});

// Refresh dashboard stats every 30 seconds
setInterval(() => {
    const currentPage = document.getElementById('pageTitle')?.textContent;
    if (currentPage === 'Dashboard') {
        Main.loadDashboardStats();
    }
}, 30000);
