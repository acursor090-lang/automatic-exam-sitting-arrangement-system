/**
 * Exams Module - Handles exam management functionality
 */

let currentEditingExamId = null;

const Exams = {
    
    init: function() {
        this.loadExams();
        this.setupEventListeners();
    },
    
    setupEventListeners: function() {
        // Add Exam Button
        document.getElementById('addExamBtn')?.addEventListener('click', () => {
            currentEditingExamId = null;
            document.getElementById('examModalTitle').textContent = 'Add Exam';
            document.getElementById('examForm').reset();
            new bootstrap.Modal(document.getElementById('examModal')).show();
        });
        
        // Submit Exam Form
        document.getElementById('submitExamBtn')?.addEventListener('click', () => {
            this.submitExamForm();
        });
        
        // Action buttons in dashboard
        document.querySelectorAll('[data-action="addExam"]').forEach(btn => {
            btn.addEventListener('click', () => {
                currentEditingExamId = null;
                document.getElementById('examModalTitle').textContent = 'Add Exam';
                document.getElementById('examForm').reset();
                new bootstrap.Modal(document.getElementById('examModal')).show();
            });
        });
        
        // Load exams in seating page
        document.getElementById('examSelect')?.addEventListener('focus', () => {
            this.loadExamsToSelect();
        });
    },
    
    loadExams: async function() {
        const result = await API.getExams();
        
        if (result.success) {
            this.displayExams(result.data);
        } else {
            alert('Error loading exams: ' + result.error);
        }
    },
    
    loadExamsToSelect: async function() {
        const result = await API.getExams();
        
        if (result.success) {
            const select = document.getElementById('examSelect');
            const currentValue = select?.value;
            
            if (select) {
                select.innerHTML = '<option value="">-- Select Exam --</option>';
                result.data.forEach(exam => {
                    const option = document.createElement('option');
                    option.value = exam.id;
                    option.textContent = `${exam.subject} - ${exam.date} ${exam.time}`;
                    select.appendChild(option);
                });
                if (currentValue) {
                    select.value = currentValue;
                }
            }
        }
    },
    
    displayExams: function(exams) {
        const tbody = document.getElementById('examTableBody');
        if (!tbody) return;
        
        tbody.innerHTML = '';
        
        if (exams.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No exams found</td></tr>';
            return;
        }
        
        exams.forEach(exam => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${exam.id}</td>
                <td>${exam.subject}</td>
                <td>${exam.date}</td>
                <td>${exam.time}</td>
                <td>${exam.duration}</td>
                <td>
                    <div class="action-buttons-group">
                        <button class="btn btn-sm btn-edit" onclick="Exams.editExam(${exam.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-delete" onclick="Exams.deleteExam(${exam.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    },
    
    submitExamForm: async function() {
        const subject = document.getElementById('examSubject').value.trim();
        const date = document.getElementById('examDate').value;
        const time = document.getElementById('examTime').value;
        const duration = document.getElementById('examDuration').value;
        
        if (!subject || !date || !time || !duration) {
            alert('All fields are required');
            return;
        }
        
        const data = {
            subject: subject,
            date: date,
            time: time,
            duration: parseInt(duration)
        };
        
        let result;
        
        if (currentEditingExamId) {
            result = await API.updateExam(currentEditingExamId, data);
        } else {
            // Check for conflicts before adding
            const conflict = await API.checkExamConflict(date, time, duration);
            if (!conflict.success) {
                alert('Error: ' + conflict.error);
                return;
            }
            
            if (conflict.conflict) {
                if (!confirm('There is an exam at this date and time. Continue anyway?')) {
                    return;
                }
            }
            
            result = await API.addExam(data);
        }
        
        if (result.success) {
            bootstrap.Modal.getInstance(document.getElementById('examModal')).hide();
            this.loadExams();
            this.loadExamsToSelect();
            alert(currentEditingExamId ? 'Exam updated successfully' : 'Exam added successfully');
        } else {
            alert('Error: ' + result.error);
        }
    },
    
    editExam: async function(id) {
        const result = await API.getExams();
        const exam = result.data.find(e => e.id === id);
        
        if (!exam) {
            alert('Exam not found');
            return;
        }
        
        currentEditingExamId = id;
        document.getElementById('examModalTitle').textContent = 'Edit Exam';
        document.getElementById('examSubject').value = exam.subject;
        document.getElementById('examDate').value = exam.date;
        document.getElementById('examTime').value = exam.time;
        document.getElementById('examDuration').value = exam.duration;
        
        new bootstrap.Modal(document.getElementById('examModal')).show();
    },
    
    deleteExam: async function(id) {
        if (!confirm('Are you sure you want to delete this exam?')) {
            return;
        }
        
        const result = await API.deleteExam(id);
        
        if (result.success) {
            this.loadExams();
            this.loadExamsToSelect();
            alert('Exam deleted successfully');
        } else {
            alert('Error deleting exam: ' + result.error);
        }
    }
};

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('examTableBody')) {
        Exams.init();
    }
});
