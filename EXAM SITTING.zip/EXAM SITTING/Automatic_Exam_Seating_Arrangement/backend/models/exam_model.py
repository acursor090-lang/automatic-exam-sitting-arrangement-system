"""
Exam model - handles exam operations
"""
from database.db import get_connection

class Exam:
    """Exam model class"""
    
    @staticmethod
    def create(subject, date, time, duration):
        """Create a new exam"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO exams (subject, date, time, duration)
                VALUES (?, ?, ?, ?)
            ''', (subject, date, time, duration))
            
            conn.commit()
            exam_id = cursor.lastrowid
            return {'success': True, 'id': exam_id}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def get_all():
        """Get all exams"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM exams ORDER BY date DESC, time DESC')
        exams = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return exams
    
    @staticmethod
    def get_by_id(exam_id):
        """Get exam by ID"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM exams WHERE id = ?', (exam_id,))
        exam = cursor.fetchone()
        conn.close()
        
        return dict(exam) if exam else None
    
    @staticmethod
    def update(exam_id, subject, date, time, duration):
        """Update exam information"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE exams 
                SET subject = ?, date = ?, time = ?, duration = ?
                WHERE id = ?
            ''', (subject, date, time, duration, exam_id))
            
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def delete(exam_id):
        """Delete an exam"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            # Delete related seating arrangements and seats
            cursor.execute('''
                DELETE FROM seats 
                WHERE exam_id = ?
            ''', (exam_id,))
            
            cursor.execute('''
                DELETE FROM seating_arrangements 
                WHERE exam_id = ?
            ''', (exam_id,))
            
            cursor.execute('DELETE FROM exams WHERE id = ?', (exam_id,))
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def check_conflicts(date, time, duration):
        """Check for exam conflicts"""
        conn = get_connection()
        cursor = conn.cursor()
        
        # Simple conflict detection: exams on same day and time
        cursor.execute('''
            SELECT * FROM exams 
            WHERE date = ? AND time = ?
        ''', (date, time))
        
        conflicts = cursor.fetchall()
        conn.close()
        
        return len(conflicts) > 0
    
    @staticmethod
    def get_total_count():
        """Get total number of exams"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) as count FROM exams')
        result = cursor.fetchone()
        conn.close()
        
        return result['count']
