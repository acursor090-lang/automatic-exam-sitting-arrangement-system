"""
Hall model - handles hall operations
"""
from database.db import get_connection

class Hall:
    """Hall model class"""
    
    @staticmethod
    def create(hall_name, capacity, floor):
        """Create a new hall"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO halls (hall_name, capacity, floor)
                VALUES (?, ?, ?)
            ''', (hall_name, capacity, floor))
            
            conn.commit()
            hall_id = cursor.lastrowid
            return {'success': True, 'id': hall_id}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def get_all():
        """Get all halls"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM halls ORDER BY floor, hall_name')
        halls = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return halls
    
    @staticmethod
    def get_by_id(hall_id):
        """Get hall by ID"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM halls WHERE id = ?', (hall_id,))
        hall = cursor.fetchone()
        conn.close()
        
        return dict(hall) if hall else None
    
    @staticmethod
    def update(hall_id, hall_name, capacity, floor):
        """Update hall information"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE halls 
                SET hall_name = ?, capacity = ?, floor = ?
                WHERE id = ?
            ''', (hall_name, capacity, floor, hall_id))
            
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def delete(hall_id):
        """Delete a hall"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            # Delete related seats
            cursor.execute('DELETE FROM seats WHERE hall_id = ?', (hall_id,))
            cursor.execute('DELETE FROM halls WHERE id = ?', (hall_id,))
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def get_total_count():
        """Get total number of halls"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) as count FROM halls')
        result = cursor.fetchone()
        conn.close()
        
        return result['count']
    
    @staticmethod
    def get_total_capacity():
        """Get total capacity of all halls"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT SUM(capacity) as total FROM halls')
        result = cursor.fetchone()
        conn.close()
        
        return result['total'] if result['total'] else 0
