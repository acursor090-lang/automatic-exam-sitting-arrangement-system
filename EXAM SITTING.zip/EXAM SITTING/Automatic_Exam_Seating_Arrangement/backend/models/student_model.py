"""
Student model - handles student operations
"""
from database.db import get_connection

class Student:
    """Student model class"""
    
    @staticmethod
    def create(name, roll_number, department, year):
        """Create a new student"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO students (name, roll_number, department, year)
                VALUES (?, ?, ?, ?)
            ''', (name, roll_number, department, year))
            
            conn.commit()
            student_id = cursor.lastrowid
            return {'success': True, 'id': student_id}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def get_all():
        """Get all students"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM students ORDER BY roll_number')
        students = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return students
    
    @staticmethod
    def get_by_id(student_id):
        """Get student by ID"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM students WHERE id = ?', (student_id,))
        student = cursor.fetchone()
        conn.close()
        
        return dict(student) if student else None
    
    @staticmethod
    def get_by_roll_number(roll_number):
        """Get student by roll number"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM students WHERE roll_number = ?', (roll_number,))
        student = cursor.fetchone()
        conn.close()
        
        return dict(student) if student else None
    
    @staticmethod
    def update(student_id, name, roll_number, department, year):
        """Update student information"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE students 
                SET name = ?, roll_number = ?, department = ?, year = ?
                WHERE id = ?
            ''', (name, roll_number, department, year, student_id))
            
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def delete(student_id):
        """Delete a student"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('DELETE FROM students WHERE id = ?', (student_id,))
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def get_by_department(department):
        """Get students by department"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM students WHERE department = ? ORDER BY roll_number', (department,))
        students = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return students
    
    @staticmethod
    def search(query):
        """Search students by name or roll number"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM students 
            WHERE name LIKE ? OR roll_number LIKE ?
            ORDER BY roll_number
        ''', (f'%{query}%', f'%{query}%'))
        
        students = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return students
