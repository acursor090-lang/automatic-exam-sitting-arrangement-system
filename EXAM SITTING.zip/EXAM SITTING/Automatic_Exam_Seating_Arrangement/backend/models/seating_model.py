"""
Seating model - handles seating arrangement operations
"""
from database.db import get_connection

class Seating:
    """Seating model class"""
    
    @staticmethod
    def create_seat(hall_id, seat_number, student_id=None, exam_id=None):
        """Create a new seat"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO seats (hall_id, seat_number, student_id, exam_id)
                VALUES (?, ?, ?, ?)
            ''', (hall_id, seat_number, student_id, exam_id))
            
            conn.commit()
            seat_id = cursor.lastrowid
            return {'success': True, 'id': seat_id}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def get_hall_seats(hall_id, exam_id=None):
        """Get all seats in a hall"""
        conn = get_connection()
        cursor = conn.cursor()
        
        if exam_id:
            cursor.execute('''
                SELECT s.*, st.name, st.roll_number, st.department 
                FROM seats s
                LEFT JOIN students st ON s.student_id = st.id
                WHERE s.hall_id = ? AND s.exam_id = ?
                ORDER BY s.seat_number
            ''', (hall_id, exam_id))
        else:
            cursor.execute('''
                SELECT s.*, st.name, st.roll_number, st.department 
                FROM seats s
                LEFT JOIN students st ON s.student_id = st.id
                WHERE s.hall_id = ?
                ORDER BY s.seat_number
            ''', (hall_id,))
        
        seats = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return seats
    
    @staticmethod
    def get_student_seat(student_id, exam_id):
        """Get seat assignment for a student in an exam"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT s.*, h.hall_name 
            FROM seats s
            JOIN halls h ON s.hall_id = h.id
            WHERE s.student_id = ? AND s.exam_id = ?
        ''', (student_id, exam_id))
        
        seat = cursor.fetchone()
        conn.close()
        
        return dict(seat) if seat else None
    
    @staticmethod
    def update_seat(seat_id, student_id=None):
        """Update seat assignment"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE seats 
                SET student_id = ?
                WHERE id = ?
            ''', (student_id, seat_id))
            
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def delete_seat(seat_id):
        """Delete a seat"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('DELETE FROM seats WHERE id = ?', (seat_id,))
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def clear_exam_seats(exam_id):
        """Clear all seats for an exam"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('DELETE FROM seats WHERE exam_id = ?', (exam_id,))
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def get_exam_seats(exam_id):
        """Get all seats allocated in an exam"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT s.*, h.hall_name, st.name, st.roll_number, st.department
            FROM seats s
            JOIN halls h ON s.hall_id = h.id
            LEFT JOIN students st ON s.student_id = st.id
            WHERE s.exam_id = ?
            ORDER BY h.hall_name, s.seat_number
        ''', (exam_id,))
        
        seats = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return seats
    
    @staticmethod
    def create_arrangement(exam_id):
        """Create a seating arrangement record"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO seating_arrangements (exam_id, finalized)
                VALUES (?, 0)
            ''', (exam_id,))
            
            conn.commit()
            arrangement_id = cursor.lastrowid
            return {'success': True, 'id': arrangement_id}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def finalize_arrangement(exam_id):
        """Finalize a seating arrangement"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                UPDATE seating_arrangements 
                SET finalized = 1
                WHERE exam_id = ?
            ''', (exam_id,))
            
            conn.commit()
            return {'success': True}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
