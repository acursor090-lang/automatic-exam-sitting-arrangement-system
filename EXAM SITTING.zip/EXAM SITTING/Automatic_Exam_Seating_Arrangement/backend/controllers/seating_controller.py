"""
Seating controller - REST API endpoints for seating arrangement
Core seating algorithm implementation
"""
import random
from models.seating_model import Seating
from models.student_model import Student
from models.exam_model import Exam
from models.hall_model import Hall
from database.db import get_connection

class SeatingController:
    """Seating controller class with core algorithm"""
    
    @staticmethod
    def generate_seat_numbers(capacity):
        """Generate seat numbers for a hall (A1, A2, etc.)"""
        seats = []
        rows = (capacity + 3) // 4  # 4 seats per row
        for i in range(rows):
            for j in range(1, 5):
                if len(seats) < capacity:
                    seats.append(f"{chr(65 + i)}{j}")
        return seats
    
    @staticmethod
    def generate_seating_arrangement(exam_id):
        """
        Core seating algorithm:
        1. Get all students
        2. Get all halls and their capacities
        3. Distribute students across halls
        4. Randomize within distribution
        5. Ensure no same department together (as much as possible)
        6. Generate seat assignments
        """
        try:
            # Get all students
            students = Student.get_all()
            if not students:
                return {'success': False, 'error': 'No students found'}
            
            # Get all halls
            halls = Hall.get_all()
            if not halls:
                return {'success': False, 'error': 'No halls found'}
            
            # Get exam
            exam = Exam.get_by_id(exam_id)
            if not exam:
                return {'success': False, 'error': 'Exam not found'}
            
            # Check if total capacity is sufficient
            total_capacity = sum([h['capacity'] for h in halls])
            if len(students) > total_capacity:
                return {
                    'success': False, 
                    'error': f'Not enough capacity. Students: {len(students)}, Capacity: {total_capacity}'
                }
            
            # Clear existing seating for this exam
            Seating.clear_exam_seats(exam_id)
            
            # Sort students by department (to try to keep them apart)
            students_by_dept = {}
            for student in students:
                dept = student['department']
                if dept not in students_by_dept:
                    students_by_dept[dept] = []
                students_by_dept[dept].append(student)
            
            # Distribute students across halls using round-robin
            # This helps distribute same department students
            student_distribution = {h['id']: [] for h in halls}
            student_queue = []
            
            # Create a queue that alternates departments
            dept_queues = {dept: list(students) for dept, students in students_by_dept.items()}
            depts = list(dept_queues.keys())
            dept_index = 0
            
            while any(dept_queues.values()):
                for _ in range(len(depts)):
                    if dept_index >= len(depts):
                        dept_index = 0
                    dept = depts[dept_index]
                    if dept_queues[dept]:
                        student_queue.append(dept_queues[dept].pop(0))
                    dept_index += 1
            
            # Randomize the final queue a bit more
            random.shuffle(student_queue)
            
            # Distribute students to halls
            hall_index = 0
            for student in student_queue:
                student_distribution[halls[hall_index]['id']].append(student)
                hall_index = (hall_index + 1) % len(halls)
            
            # Create actual seat assignments
            seat_count = 0
            for hall in halls:
                hall_id = hall['id']
                capacity = hall['capacity']
                
                # Generate seat numbers for this hall
                seat_numbers = SeatingController.generate_seat_numbers(capacity)
                
                # Shuffle seat numbers to randomize
                random.shuffle(seat_numbers)
                
                # Assign students to seats
                hall_students = student_distribution[hall_id]
                
                for i, student in enumerate(hall_students):
                    if i < len(seat_numbers):
                        Seating.create_seat(
                            hall_id, 
                            seat_numbers[i], 
                            student['id'],
                            exam_id
                        )
                        seat_count += 1
            
            # Create seating arrangement record
            Seating.create_arrangement(exam_id)
            
            return {
                'success': True, 
                'message': f'Seating arrangement created for {seat_count} students',
                'seats_created': seat_count
            }
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    @staticmethod
    def get_exam_seating_layout(exam_id):
        """Get seating layout for exam (organized by hall)"""
        seats = Seating.get_exam_seats(exam_id)
        
        # Organize by hall
        layout = {}
        for seat in seats:
            hall_name = seat['hall_name']
            if hall_name not in layout:
                layout[hall_name] = []
            layout[hall_name].append(seat)
        
        return {'success': True, 'data': layout}
    
    @staticmethod
    def search_student_seat(student_roll_number, exam_id):
        """Search where a student is seated in an exam"""
        student = Student.get_by_roll_number(student_roll_number)
        
        if not student:
            return {'success': False, 'error': 'Student not found'}
        
        seat = Seating.get_student_seat(student['id'], exam_id)
        
        if not seat:
            return {'success': False, 'error': 'Seat not allocated for this student'}
        
        return {'success': True, 'data': seat}
    
    @staticmethod
    def get_hall_layout(hall_id, exam_id):
        """Get seat layout for a specific hall in an exam"""
        seats = Seating.get_hall_seats(hall_id, exam_id)
        
        if not seats:
            return {'success': False, 'error': 'No seats found'}
        
        # Organize seats for display
        layout = {
            'total_seats': len(seats),
            'occupied_seats': len([s for s in seats if s['student_id']]),
            'available_seats': len([s for s in seats if not s['student_id']]),
            'seats': seats
        }
        
        return {'success': True, 'data': layout}
    
    @staticmethod
    def finalize_seating(exam_id):
        """Finalize seating arrangement"""
        result = Seating.finalize_arrangement(exam_id)
        return result
    
    @staticmethod
    def get_attendance_sheet(exam_id, hall_id=None):
        """Generate attendance sheet for an exam"""
        if hall_id:
            seats = Seating.get_hall_seats(hall_id, exam_id)
        else:
            seats = Seating.get_exam_seats(exam_id)
        
        # Sort by seat number
        seats = sorted(seats, key=lambda x: x['seat_number'])
        
        attendance = []
        for seat in seats:
            if seat['student_id']:  # Only for allocated seats
                attendance.append({
                    'roll_number': seat['roll_number'],
                    'name': seat['name'],
                    'seat_number': seat['seat_number'],
                    'hall_name': seat.get('hall_name', 'N/A'),
                    'signature': ''
                })
        
        return {'success': True, 'data': attendance}
    
    @staticmethod
    def get_seating_statistics(exam_id):
        """Get statistics about seating arrangement"""
        seats = Seating.get_exam_seats(exam_id)
        halls = Hall.get_all()
        
        stats = {
            'total_students': len([s for s in seats if s['student_id']]),
            'total_seats': len(seats),
            'total_halls': len(halls),
            'halls_with_students': len(set([s['hall_id'] for s in seats if s['student_id']])),
            'available_seats': len([s for s in seats if not s['student_id']])
        }
        
        return {'success': True, 'data': stats}
