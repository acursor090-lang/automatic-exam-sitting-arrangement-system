"""
Student controller - REST API endpoints for student management
"""
from models.student_model import Student

class StudentController:
    """Student controller class"""
    
    @staticmethod
    def add_student(name, roll_number, department, year):
        """Add a new student"""
        if not all([name, roll_number, department, year]):
            return {'success': False, 'error': 'All fields are required'}
        
        result = Student.create(name, roll_number, department, year)
        return result
    
    @staticmethod
    def get_students():
        """Get all students"""
        students = Student.get_all()
        return {'success': True, 'data': students}
    
    @staticmethod
    def get_student(student_id):
        """Get student by ID"""
        student = Student.get_by_id(student_id)
        
        if not student:
            return {'success': False, 'error': 'Student not found'}
        
        return {'success': True, 'data': student}
    
    @staticmethod
    def edit_student(student_id, name, roll_number, department, year):
        """Edit student information"""
        if not all([name, roll_number, department, year]):
            return {'success': False, 'error': 'All fields are required'}
        
        result = Student.update(student_id, name, roll_number, department, year)
        return result
    
    @staticmethod
    def delete_student(student_id):
        """Delete a student"""
        result = Student.delete(student_id)
        return result
    
    @staticmethod
    def search_students(query):
        """Search students"""
        if not query:
            return {'success': False, 'error': 'Query required'}
        
        students = Student.search(query)
        return {'success': True, 'data': students}
    
    @staticmethod
    def get_students_by_department(department):
        """Get students by department"""
        if not department:
            return {'success': False, 'error': 'Department required'}
        
        students = Student.get_by_department(department)
        return {'success': True, 'data': students}
    
    @staticmethod
    def get_total_students():
        """Get total number of students"""
        students = Student.get_all()
        return {'success': True, 'count': len(students)}
    
    @staticmethod
    def get_departments():
        """Get all departments"""
        students = Student.get_all()
        departments = list(set([s['department'] for s in students]))
        return {'success': True, 'departments': sorted(departments)}
