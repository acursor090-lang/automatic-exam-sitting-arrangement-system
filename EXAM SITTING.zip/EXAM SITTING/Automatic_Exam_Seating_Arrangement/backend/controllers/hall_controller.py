"""
Hall controller - REST API endpoints for hall management
"""
from models.hall_model import Hall

class HallController:
    """Hall controller class"""
    
    @staticmethod
    def add_hall(hall_name, capacity, floor):
        """Add a new hall"""
        if not all([hall_name, capacity, floor]):
            return {'success': False, 'error': 'All fields are required'}
        
        try:
            capacity = int(capacity)
            floor = int(floor)
        except:
            return {'success': False, 'error': 'Capacity and floor must be numbers'}
        
        result = Hall.create(hall_name, capacity, floor)
        return result
    
    @staticmethod
    def get_halls():
        """Get all halls"""
        halls = Hall.get_all()
        return {'success': True, 'data': halls}
    
    @staticmethod
    def get_hall(hall_id):
        """Get hall by ID"""
        hall = Hall.get_by_id(hall_id)
        
        if not hall:
            return {'success': False, 'error': 'Hall not found'}
        
        return {'success': True, 'data': hall}
    
    @staticmethod
    def edit_hall(hall_id, hall_name, capacity, floor):
        """Edit hall information"""
        if not all([hall_name, capacity, floor]):
            return {'success': False, 'error': 'All fields are required'}
        
        try:
            capacity = int(capacity)
            floor = int(floor)
        except:
            return {'success': False, 'error': 'Capacity and floor must be numbers'}
        
        result = Hall.update(hall_id, hall_name, capacity, floor)
        return result
    
    @staticmethod
    def delete_hall(hall_id):
        """Delete a hall"""
        result = Hall.delete(hall_id)
        return result
    
    @staticmethod
    def get_total_halls():
        """Get total number of halls"""
        count = Hall.get_total_count()
        return {'success': True, 'count': count}
    
    @staticmethod
    def get_total_capacity():
        """Get total capacity of all halls"""
        capacity = Hall.get_total_capacity()
        return {'success': True, 'total_capacity': capacity}
