"""
Exam controller - REST API endpoints for exam management
"""
from models.exam_model import Exam

class ExamController:
    """Exam controller class"""
    
    @staticmethod
    def add_exam(subject, date, time, duration):
        """Add a new exam"""
        if not all([subject, date, time, duration]):
            return {'success': False, 'error': 'All fields are required'}
        
        # Check for conflicts
        if Exam.check_conflicts(date, time, duration):
            return {'success': False, 'error': 'Exam conflict detected at this date and time'}
        
        result = Exam.create(subject, date, time, duration)
        return result
    
    @staticmethod
    def get_exams():
        """Get all exams"""
        exams = Exam.get_all()
        return {'success': True, 'data': exams}
    
    @staticmethod
    def get_exam(exam_id):
        """Get exam by ID"""
        exam = Exam.get_by_id(exam_id)
        
        if not exam:
            return {'success': False, 'error': 'Exam not found'}
        
        return {'success': True, 'data': exam}
    
    @staticmethod
    def edit_exam(exam_id, subject, date, time, duration):
        """Edit exam information"""
        if not all([subject, date, time, duration]):
            return {'success': False, 'error': 'All fields are required'}
        
        result = Exam.update(exam_id, subject, date, time, duration)
        return result
    
    @staticmethod
    def delete_exam(exam_id):
        """Delete an exam"""
        result = Exam.delete(exam_id)
        return result
    
    @staticmethod
    def check_conflict(date, time, duration):
        """Check for exam conflicts"""
        if Exam.check_conflicts(date, time, duration):
            return {'success': False, 'error': 'Conflict detected', 'conflict': True}
        
        return {'success': True, 'conflict': False}
    
    @staticmethod
    def get_total_exams():
        """Get total number of exams"""
        count = Exam.get_total_count()
        return {'success': True, 'count': count}
