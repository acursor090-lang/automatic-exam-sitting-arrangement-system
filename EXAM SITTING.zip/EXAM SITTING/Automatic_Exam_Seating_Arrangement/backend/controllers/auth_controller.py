"""
Authentication controller - handles login and authentication
"""
from database.db import get_connection
import hashlib

class AuthController:
    """Authentication controller class"""
    
    @staticmethod
    def hash_password(password):
        """Hash password using SHA256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    @staticmethod
    def create_admin(username, password):
        """Create admin user"""
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            hashed_password = AuthController.hash_password(password)
            cursor.execute('''
                INSERT INTO admin_users (username, password)
                VALUES (?, ?)
            ''', (username, hashed_password))
            
            conn.commit()
            admin_id = cursor.lastrowid
            return {'success': True, 'id': admin_id}
        except Exception as e:
            conn.rollback()
            return {'success': False, 'error': str(e)}
        finally:
            conn.close()
    
    @staticmethod
    def verify_admin(username, password):
        """Verify admin credentials"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM admin_users WHERE username = ?', (username,))
        admin = cursor.fetchone()
        conn.close()
        
        if not admin:
            return {'success': False, 'error': 'User not found'}
        
        hashed_password = AuthController.hash_password(password)
        
        if admin['password'] == hashed_password:
            return {'success': True, 'id': admin['id'], 'username': admin['username']}
        else:
            return {'success': False, 'error': 'Invalid password'}
    
    @staticmethod
    def get_admin(username):
        """Get admin user"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT id, username FROM admin_users WHERE username = ?', (username,))
        admin = cursor.fetchone()
        conn.close()
        
        return dict(admin) if admin else None
    
    @staticmethod
    def admin_exists():
        """Check if admin user exists"""
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) as count FROM admin_users')
        result = cursor.fetchone()
        conn.close()
        
        return result['count'] > 0
