"""
Automated Exam Seating Arrangement System
Main Flask Application

Author: Admin
Version: 1.0
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from functools import wraps
import os
import sys
from datetime import datetime

# Add backend directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

# Import database and models
from backend.database.db import init_db
from backend.controllers.auth_controller import AuthController
from backend.controllers.student_controller import StudentController
from backend.controllers.exam_controller import ExamController
from backend.controllers.hall_controller import HallController
from backend.controllers.seating_controller import SeatingController

# Initialize Flask app
app = Flask(__name__, template_folder='../frontend/html', static_folder='../frontend')
app.secret_key = 'your-secret-key-change-this'

# Initialize database
init_db()

# Decorator for login required
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ==================== AUTH ROUTES ====================

@app.route('/', methods=['GET'])
def index():
    """Index route - redirect to dashboard if logged in, else to login"""
    if 'admin_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page and authentication"""
    if request.method == 'GET':
        if 'admin_id' in session:
            return redirect(url_for('dashboard'))
        return render_template('login.html')
    
    # POST request - authenticate
    username = request.form.get('username')
    password = request.form.get('password')
    
    if not username or not password:
        return render_template('login.html', error='Username and password are required')
    
    # Check if admin exists, if not create default admin
    if not AuthController.admin_exists():
        AuthController.create_admin('admin', 'admin123')
    
    # Verify credentials
    result = AuthController.verify_admin(username, password)
    
    if result['success']:
        session['admin_id'] = result['id']
        session['username'] = result['username']
        return redirect(url_for('dashboard'))
    else:
        return render_template('login.html', error=result['error'])

@app.route('/logout', methods=['GET'])
def logout():
    """Logout route"""
    session.clear()
    return redirect(url_for('login'))

# ==================== PAGE ROUTES ====================

@app.route('/dashboard', methods=['GET'])
@login_required
def dashboard():
    """Dashboard page"""
    return render_template('dashboard.html', username=session.get('username'))

@app.route('/students', methods=['GET'])
@login_required
def students():
    """Students management page"""
    return render_template('students.html')

@app.route('/exams', methods=['GET'])
@login_required
def exams():
    """Exams management page"""
    return render_template('exams.html')

@app.route('/halls', methods=['GET'])
@login_required
def halls():
    """Halls management page"""
    return render_template('halls.html')

@app.route('/seating', methods=['GET'])
@login_required
def seating():
    """Seating arrangement page"""
    return render_template('seating.html')

@app.route('/reports', methods=['GET'])
@login_required
def reports():
    """Reports page"""
    return render_template('reports.html')

# ==================== API ROUTES - STUDENTS ====================

@app.route('/api/students', methods=['GET'])
@login_required
def get_students():
    """Get all students"""
    result = StudentController.get_students()
    return jsonify(result)

@app.route('/api/students', methods=['POST'])
@login_required
def add_student():
    """Add new student"""
    data = request.get_json()
    result = StudentController.add_student(
        data.get('name'),
        data.get('roll_number'),
        data.get('department'),
        data.get('year')
    )
    return jsonify(result)

@app.route('/api/students/<int:student_id>', methods=['GET'])
@login_required
def get_student(student_id):
    """Get student by ID"""
    result = StudentController.get_student(student_id)
    return jsonify(result)

@app.route('/api/students/<int:student_id>', methods=['PUT'])
@login_required
def edit_student(student_id):
    """Edit student"""
    data = request.get_json()
    result = StudentController.edit_student(
        student_id,
        data.get('name'),
        data.get('roll_number'),
        data.get('department'),
        data.get('year')
    )
    return jsonify(result)

@app.route('/api/students/<int:student_id>', methods=['DELETE'])
@login_required
def delete_student(student_id):
    """Delete student"""
    result = StudentController.delete_student(student_id)
    return jsonify(result)

@app.route('/api/students/search', methods=['GET'])
@login_required
def search_students():
    """Search students"""
    query = request.args.get('q', '')
    result = StudentController.search_students(query)
    return jsonify(result)

@app.route('/api/students/department/<department>', methods=['GET'])
@login_required
def get_students_by_department(department):
    """Get students by department"""
    result = StudentController.get_students_by_department(department)
    return jsonify(result)

@app.route('/api/students/stats/total', methods=['GET'])
@login_required
def get_total_students():
    """Get total students count"""
    result = StudentController.get_total_students()
    return jsonify(result)

@app.route('/api/departments', methods=['GET'])
@login_required
def get_departments():
    """Get all departments"""
    result = StudentController.get_departments()
    return jsonify(result)

# ==================== API ROUTES - EXAMS ====================

@app.route('/api/exams', methods=['GET'])
@login_required
def get_exams():
    """Get all exams"""
    result = ExamController.get_exams()
    return jsonify(result)

@app.route('/api/exams', methods=['POST'])
@login_required
def add_exam():
    """Add new exam"""
    data = request.get_json()
    result = ExamController.add_exam(
        data.get('subject'),
        data.get('date'),
        data.get('time'),
        data.get('duration')
    )
    return jsonify(result)

@app.route('/api/exams/<int:exam_id>', methods=['GET'])
@login_required
def get_exam(exam_id):
    """Get exam by ID"""
    result = ExamController.get_exam(exam_id)
    return jsonify(result)

@app.route('/api/exams/<int:exam_id>', methods=['PUT'])
@login_required
def edit_exam(exam_id):
    """Edit exam"""
    data = request.get_json()
    result = ExamController.edit_exam(
        exam_id,
        data.get('subject'),
        data.get('date'),
        data.get('time'),
        data.get('duration')
    )
    return jsonify(result)

@app.route('/api/exams/<int:exam_id>', methods=['DELETE'])
@login_required
def delete_exam(exam_id):
    """Delete exam"""
    result = ExamController.delete_exam(exam_id)
    return jsonify(result)

@app.route('/api/exams/check-conflict', methods=['POST'])
@login_required
def check_exam_conflict():
    """Check for exam conflicts"""
    data = request.get_json()
    result = ExamController.check_conflict(
        data.get('date'),
        data.get('time'),
        data.get('duration')
    )
    return jsonify(result)

@app.route('/api/exams/stats/total', methods=['GET'])
@login_required
def get_total_exams():
    """Get total exams count"""
    result = ExamController.get_total_exams()
    return jsonify(result)

# ==================== API ROUTES - HALLS ====================

@app.route('/api/halls', methods=['GET'])
@login_required
def get_halls_api():
    """Get all halls"""
    result = HallController.get_halls()
    return jsonify(result)

@app.route('/api/halls', methods=['POST'])
@login_required
def add_hall():
    """Add new hall"""
    data = request.get_json()
    result = HallController.add_hall(
        data.get('hall_name'),
        data.get('capacity'),
        data.get('floor')
    )
    return jsonify(result)

@app.route('/api/halls/<int:hall_id>', methods=['GET'])
@login_required
def get_hall(hall_id):
    """Get hall by ID"""
    result = HallController.get_hall(hall_id)
    return jsonify(result)

@app.route('/api/halls/<int:hall_id>', methods=['PUT'])
@login_required
def edit_hall(hall_id):
    """Edit hall"""
    data = request.get_json()
    result = HallController.edit_hall(
        hall_id,
        data.get('hall_name'),
        data.get('capacity'),
        data.get('floor')
    )
    return jsonify(result)

@app.route('/api/halls/<int:hall_id>', methods=['DELETE'])
@login_required
def delete_hall(hall_id):
    """Delete hall"""
    result = HallController.delete_hall(hall_id)
    return jsonify(result)

@app.route('/api/halls/stats/total', methods=['GET'])
@login_required
def get_total_halls():
    """Get total halls count"""
    result = HallController.get_total_halls()
    return jsonify(result)

@app.route('/api/halls/stats/capacity', methods=['GET'])
@login_required
def get_total_capacity():
    """Get total capacity"""
    result = HallController.get_total_capacity()
    return jsonify(result)

# ==================== API ROUTES - SEATING ====================

@app.route('/api/seating/generate/<int:exam_id>', methods=['POST'])
@login_required
def generate_seating(exam_id):
    """Generate seating arrangement for exam"""
    result = SeatingController.generate_seating_arrangement(exam_id)
    return jsonify(result)

@app.route('/api/seating/layout/<int:exam_id>', methods=['GET'])
@login_required
def get_seating_layout(exam_id):
    """Get seating layout for exam"""
    result = SeatingController.get_exam_seating_layout(exam_id)
    return jsonify(result)

@app.route('/api/seating/search', methods=['GET'])
@login_required
def search_student_seat():
    """Search student seat"""
    roll_number = request.args.get('roll_number')
    exam_id = request.args.get('exam_id')
    
    result = SeatingController.search_student_seat(roll_number, exam_id)
    return jsonify(result)

@app.route('/api/seating/hall/<int:hall_id>/exam/<int:exam_id>', methods=['GET'])
@login_required
def get_hall_layout(hall_id, exam_id):
    """Get hall seating layout"""
    result = SeatingController.get_hall_layout(hall_id, exam_id)
    return jsonify(result)

@app.route('/api/seating/finalize/<int:exam_id>', methods=['POST'])
@login_required
def finalize_seating(exam_id):
    """Finalize seating arrangement"""
    result = SeatingController.finalize_seating(exam_id)
    return jsonify(result)

@app.route('/api/seating/attendance/<int:exam_id>', methods=['GET'])
@login_required
def get_attendance_sheet(exam_id):
    """Get attendance sheet for exam"""
    hall_id = request.args.get('hall_id')
    if hall_id:
        result = SeatingController.get_attendance_sheet(exam_id, int(hall_id))
    else:
        result = SeatingController.get_attendance_sheet(exam_id)
    return jsonify(result)

@app.route('/api/seating/statistics/<int:exam_id>', methods=['GET'])
@login_required
def get_seating_statistics(exam_id):
    """Get seating statistics"""
    result = SeatingController.get_seating_statistics(exam_id)
    return jsonify(result)

# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    """404 error handler"""
    return jsonify({'success': False, 'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    """500 error handler"""
    return jsonify({'success': False, 'error': 'Internal server error'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
