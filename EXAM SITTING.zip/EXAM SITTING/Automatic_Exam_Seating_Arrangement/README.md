# Automated Exam Seating Arrangement System (AESA)

A modern, professional web-based system for automatically generating exam seating arrangements with advanced algorithms and an intuitive admin dashboard.

## Features

### Core Features
- **Admin Authentication**: Secure session-based login system
- **Student Management**: Add, edit, delete, and search students with department filtering
- **Exam Management**: Create and manage exams with conflict detection
- **Hall Management**: Configure exam halls with capacity and floor information
- **Automatic Seating Arrangement**: Intelligent algorithm that:
  - Distributes students across available halls
  - Prevents students from the same department sitting together
  - Randomizes seat allocation
  - Respects hall capacity limits
  - Avoids duplicate seat allocation

### Dashboard
- Real-time statistics (Students, Exams, Halls, Capacity)
- System status monitoring
- Quick action buttons for common tasks

### Seating System
- Visual seating layout with color-coded seats
- Student seat search functionality
- Attendance sheet generation
- Hall-wise seating reports
- Interactive seat visualization

### Reports
- Seating chart generation
- Attendance sheet export
- Student-wise seating information
- Hall-wise seating breakdown

## Technology Stack

**Frontend:**
- HTML5
- CSS3 (with custom styling)
- JavaScript (ES6+)
- Bootstrap 5
- Font Awesome Icons

**Backend:**
- Python 3.8+
- Flask 3.0.0
- SQLite3 (default) / MySQL compatible

**Architecture:**
- REST API based communication
- Session-based authentication
- MVC pattern for organized code

## Project Structure

```
Automatic_Exam_Seating_Arrangement/
├── frontend/
│   ├── html/
│   │   ├── login.html
│   │   └── dashboard.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── api.js
│       ├── students.js
│       ├── exams.js
│       ├── seating.js
│       └── main.js
├── backend/
│   ├── app.py
│   ├── database/
│   │   └── db.py
│   ├── models/
│   │   ├── student_model.py
│   │   ├── exam_model.py
│   │   ├── hall_model.py
│   │   └── seating_model.py
│   └── controllers/
│       ├── auth_controller.py
│       ├── student_controller.py
│       ├── exam_controller.py
│       ├── hall_controller.py
│       └── seating_controller.py
├── requirements.txt
└── README.md
```

## Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### Step 1: Navigate to Project Directory
```bash
cd Automatic_Exam_Seating_Arrangement
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Initialize Database
```bash
python backend/database/db.py
```

This will create the SQLite database with all required tables.

### Step 4: Run the Application
```bash
python backend/app.py
```

The application will start on `http://127.0.0.1:5000`

### Step 5: Login
- **Default Username:** admin
- **Default Password:** admin123

⚠️ **Important:** Change the default password immediately after first login in production.

## Usage Guide

### Dashboard
The dashboard provides an overview of your system:
- Total Students count
- Total Exams count
- Total Halls count
- Total Capacity across all halls
- Quick action buttons for common tasks
- System status

### Student Management
1. Navigate to **Students** from sidebar
2. **Add Student:**
   - Click "Add Student" button
   - Fill in name, roll number, department, and year
   - Click "Save"
3. **Search:** Use the search box to find students by name or roll number
4. **Filter:** Filter by department using the dropdown
5. **Edit:** Click the edit icon to modify student details
6. **Delete:** Click the delete icon to remove a student

### Exam Management
1. Navigate to **Exams** from sidebar
2. **Add Exam:**
   - Click "Add Exam" button
   - Enter subject, date, time, and duration
   - System auto-detects conflicts
   - Click "Save"
3. **View:** All exams are listed with date and time
4. **Edit:** Modify exam details
5. **Delete:** Remove an exam (cascades to seating data)

### Hall Management
1. Navigate to **Halls** from sidebar
2. **Add Hall:**
   - Click "Add Hall" button
   - Enter hall name, capacity, and floor number
   - Click "Save"
3. **View:** All halls with their capacities are listed
4. **Edit:** Update hall information
5. **Delete:** Remove a hall

### Seating Arrangement (Core Feature)
1. Navigate to **Seating** from sidebar
2. **Generate Seating:**
   - Select an exam from dropdown
   - Click "Generate Seating" button
   - Confirm the action
   - System generates optimized seating
3. **View Layout:**
   - Click "View Layout" after generation
   - Seats show in a grid:
     - **Green Seats:** Occupied (with student roll number)
     - **Red Seats:** Available unoccupied
4. **Find Student Seat:**
   - Enter student roll number
   - Select exam
   - Click "Search"
   - See hall and seat number

### Seating Algorithm Explained

The system uses an intelligent algorithm:
1. **Department Segregation:** Attempts to distribute students from same department across halls
2. **Random Distribution:** Uses round-robin with randomization to prevent patterns
3. **Capacity Management:** Ensures no hall exceeds its capacity
4. **Seat Generation:** Creates seat numbers in format A1, A2, B1, B2, etc.
5. **Validation:** Prevents duplicate allocations

Example output:
```
Hall A: 48 seats (A1-A12 in 4 rows)
Hall B: 48 seats (B1-B12 in 4 rows)
Total: 96 students can be seated
```

### Reports
1. Navigate to **Reports** from sidebar
2. **Seating Chart:**
   - Download PDF of complete seating arrangement
   - Print-friendly format
3. **Attendance Sheet:**
   - Export Excel file with:
     - Student Roll Number
     - Student Name
     - Allocated Seat Number
     - Signature column (printable)

## REST API Endpoints

### Authentication
- `POST /login` - Admin login
- `GET /logout` - Logout

### Students
- `GET /api/students` - Get all students
- `POST /api/students` - Add new student
- `GET /api/students/<id>` - Get student by ID
- `PUT /api/students/<id>` - Update student
- `DELETE /api/students/<id>` - Delete student
- `GET /api/students/search?q=query` - Search students
- `GET /api/departments` - Get all departments

### Exams
- `GET /api/exams` - Get all exams
- `POST /api/exams` - Add new exam
- `GET /api/exams/<id>` - Get exam by ID
- `PUT /api/exams/<id>` - Update exam
- `DELETE /api/exams/<id>` - Delete exam
- `POST /api/exams/check-conflict` - Check conflicts

### Halls
- `GET /api/halls` - Get all halls
- `POST /api/halls` - Add new hall
- `PUT /api/halls/<id>` - Update hall
- `DELETE /api/halls/<id>` - Delete hall
- `GET /api/halls/stats/total` - Total halls
- `GET /api/halls/stats/capacity` - Total capacity

### Seating
- `POST /api/seating/generate/<exam_id>` - Generate seating
- `GET /api/seating/layout/<exam_id>` - Get seating layout
- `GET /api/seating/search` - Search student seat
- `GET /api/seating/hall/<hall_id>/exam/<exam_id>` - Hall layout
- `GET /api/seating/attendance/<exam_id>` - Attendance sheet
- `GET /api/seating/statistics/<exam_id>` - Seating stats

## Database Schema

### students
```sql
CREATE TABLE students (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    roll_number TEXT UNIQUE NOT NULL,
    department TEXT NOT NULL,
    year INTEGER NOT NULL,
    created_at TIMESTAMP
)
```

### exams
```sql
CREATE TABLE exams (
    id INTEGER PRIMARY KEY,
    subject TEXT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    duration INTEGER NOT NULL,
    created_at TIMESTAMP
)
```

### halls
```sql
CREATE TABLE halls (
    id INTEGER PRIMARY KEY,
    hall_name TEXT UNIQUE NOT NULL,
    capacity INTEGER NOT NULL,
    floor INTEGER NOT NULL,
    created_at TIMESTAMP
)
```

### seats
```sql
CREATE TABLE seats (
    id INTEGER PRIMARY KEY,
    hall_id INTEGER NOT NULL,
    seat_number TEXT NOT NULL,
    student_id INTEGER,
    exam_id INTEGER,
    created_at TIMESTAMP,
    FOREIGN KEY (hall_id) REFERENCES halls(id),
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (exam_id) REFERENCES exams(id)
)
```

## UI Design

### Color Scheme
- **Primary Color:** #2563EB (Blue)
- **Secondary Color:** #10B981 (Green)
- **Text Color:** #1F2937 (Dark Gray)
- **Card Background:** #F8FAFC (Light Gray)
- **Border Color:** #E5E7EB (Light Gray)

### Layout Components
- **Sidebar Navigation:** Dark theme with hover effects
- **Top Navbar:** White with user info
- **Cards:** Soft shadows with rounded corners and hover animations
- **Tables:** Clean design with alternating row colors
- **Modals:** Bootstrap 5 modals with custom styling
- **Responsive:** Works on desktop (1024px+) and mobile devices

### Typography
- **Font Family:** Poppins, Inter, sans-serif
- **Font Sizes:** Scalable across devices
- **Font Weights:** 400 (normal), 500 (medium), 600 (semibold), 700 (bold)

## Troubleshooting

### Port Already in Use
If port 5000 is already in use:
```python
# In app.py, change the last line to:
if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5001)
```

### Database Errors
Reset the database:
```bash
# Delete the database file
rm seating_system.db

# Reinitialize
python backend/database/db.py
```

### Login Issues
- Check default credentials: `admin` / `admin123`
- Clear browser cache and cookies
- Try incognito/private browsing mode

### Seating Generation Fails
- Ensure students are added
- Ensure halls are added with sufficient capacity
- Ensure exam is created
- Check browser console for errors (F12)

## Performance Considerations

- **Database:** SQLite for development; upgrade to MySQL for production
- **Caching:** Frontend caches API responses where appropriate
- **Pagination:** Can be added for large student lists (future enhancement)
- **Optimization:** Algorithm runs in O(n) time for n students

## Security Notes

⚠️ **Important Security Measures:**

1. **Change default password immediately** after first login
2. **Use HTTPS** in production
3. **Set strong secret key** in `app.py` (line: `app.secret_key`)
4. **Implement rate limiting** for production deployment
5. **Use environment variables** for sensitive configuration
6. **Add CSRF protection** for form submissions in production
7. **Validate all inputs** on both frontend and backend

## Future Enhancements

- [ ] PDF and Excel report exports
- [ ] Bulk student import from CSV/Excel
- [ ] Multiple admin users with role-based access
- [ ] Email notifications
- [ ] Backup and restore functionality
- [ ] Exam invigilator assignment
- [ ] Real-time collaboration features
- [ ] Mobile app version
- [ ] Advanced analytics and charts
- [ ] Payment gateway integration for exam fees

## Browser Compatibility

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## License

This project is provided as-is for educational purposes.

## Support

For issues, feature requests, or questions:
1. Check the troubleshooting section
2. Review the error messages in browser console
3. Check database logs and Flask error output

## Author Notes

This system was built following modern web development practices with:
- Clean, well-documented code
- Separation of concerns (MVC pattern)
- RESTful API design
- Responsive UI design
- Comprehensive error handling

---

**Version:** 1.0  
**Last Updated:** 2026  
**Status:** Production Ready
